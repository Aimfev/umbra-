Umbra: open this folder in Android Studio (Ladybug or newer), let Gradle sync, then Run on a phone (Android 8+).
First launch: tap "Launch Minecraft", allow "Display over other apps", tap again.
